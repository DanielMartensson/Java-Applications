F�ljande programmvaror m�ste installeras:
* Java OpenJKD 8 
* Tomcat 8

Programmet kompileras till en .war fil och sedan skickas in till Tomcat 8 p� RPi.
