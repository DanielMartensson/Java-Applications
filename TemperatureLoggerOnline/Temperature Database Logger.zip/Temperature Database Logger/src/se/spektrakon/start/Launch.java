package se.spektrakon.start;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import se.spektrakon.database.JdbcMethods;
import se.spektrakon.hardware.Computer;
import se.spektrakon.hardware.SerialLock;
import se.spektrakon.view.Line;

@ManagedBean
@ApplicationScoped
public class Launch {
	private Computer computer;
	private Line line;
	private JdbcMethods jdbcMethods;
	private final String serialNumber = "00000000f69c090e"; // Raspberry Pi 3 B+

	/*
	 * Init taskes and objects
	 */
	public Launch() throws ClassNotFoundException {
		// First check if there is correct CPU
		if(new SerialLock(serialNumber).isCorrectCPU()) {
			jdbcMethods = new JdbcMethods();
			computer = new Computer();
			line = new Line(computer, jdbcMethods);
			computer.start();
			line.start();
		}
	}

	public JdbcMethods getJdbcMethods() {
		return jdbcMethods;
	}

	public void setJdbcMethods(JdbcMethods jdbcMethods) {
		this.jdbcMethods = jdbcMethods;
	}

	public Computer getComputer() {
		return computer;
	}

	public void setComputer(Computer computer) {
		this.computer = computer;
	}

	public Line getLine() {
		return line;
	}

	public void setLine(Line line) {
		this.line = line;
	}
	
	
	
	
	

	
	
}
