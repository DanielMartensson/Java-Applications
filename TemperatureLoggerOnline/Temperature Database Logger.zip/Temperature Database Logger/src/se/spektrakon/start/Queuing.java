package se.spektrakon.start;

public class Queuing {
	/*
	 * Initial simple thread. We start with reading temperature
	 */
	public static boolean callComputerThread = true;
	public static boolean callLineThread = false;
}
