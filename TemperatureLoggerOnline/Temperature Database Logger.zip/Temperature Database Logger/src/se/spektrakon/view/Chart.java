package se.spektrakon.view;

import java.util.ArrayList;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.CategoryAxis;
import org.primefaces.model.chart.ChartSeries;
import org.primefaces.model.chart.LegendPlacement;
import org.primefaces.model.chart.LineChartModel;

@ManagedBean
@ApplicationScoped
public class Chart {
	private LineChartModel lineChartModel;
	private ArrayList<String> timeList;
	private ArrayList<Double> temperatureList0;
	private ArrayList<Double> temperatureList1;
	private ArrayList<Double> temperatureList2;
	private ArrayList<Double> temperatureList3;
	private ArrayList<Double> temperatureList4;
	private final int ARRAY_LENGTH = 72; 
	private ChartSeries chartSeries0;
	private ChartSeries chartSeries1;
	private ChartSeries chartSeries2;
	private ChartSeries chartSeries3;
	private ChartSeries chartSeries4;
	private int samples;

	/*
	 * Create the line chart
	 */
	public Chart() {
		
		// Initi the ArrayList's
		timeList = new ArrayList<>();
		temperatureList0 = new ArrayList<>();
		temperatureList1 = new ArrayList<>();
		temperatureList2 = new ArrayList<>();
		temperatureList3 = new ArrayList<>();
		temperatureList4 = new ArrayList<>();

		// Model
		lineChartModel = new LineChartModel();

		// Init
		lineChartModel = init(lineChartModel);
		
	}
	
	/*
	 * Set up the chart
	 */
	private LineChartModel init(LineChartModel lineChartModel_init) {
		
		// Set zoom
		lineChartModel_init.setZoom(true);
		
		// Labels and title
		lineChartModel_init.getAxis(AxisType.X).setLabel("Minutes");
		lineChartModel_init.getAxis(AxisType.Y).setLabel("Degrees �C");
		
		// Legend
		lineChartModel_init.setLegendPosition("ne"); // North east
		lineChartModel_init.setLegendPlacement(LegendPlacement.OUTSIDEGRID);

		// Limit
		Axis yAxis = lineChartModel_init.getAxis(AxisType.Y);
		yAxis.setMin(-40);
		yAxis.setMax(125);

		// Modify the x-axis
		CategoryAxis xAxis = new CategoryAxis("Time");
		xAxis.setTickAngle(-50);
		lineChartModel_init.getAxes().put(AxisType.X, xAxis);
		
		return lineChartModel_init;

	}

	public void addToChart(double temperature0, double temperature1, double temperature2, double temperature3, double temperature4, String time) {
		// Collect time and temperature inside an array
		// If the length is over 72 samples
		if (timeList.size() >= ARRAY_LENGTH) {
			// Remove the first one and add the last one
			if (!timeList.contains(time)) {
				timeList.add(time);
				timeList.remove(0);
				temperatureList0.add(temperature0);
				temperatureList0.remove(0);
				temperatureList1.add(temperature1);
				temperatureList1.remove(0);
				temperatureList2.add(temperature2);
				temperatureList2.remove(0);
				temperatureList3.add(temperature3);
				temperatureList3.remove(0);
				temperatureList4.add(temperature4);
				temperatureList4.remove(0);
			}

		} else {
			// Only add if it not contains
			if (!timeList.contains(time)) {
				timeList.add(time);
				temperatureList0.add(temperature0);
				temperatureList1.add(temperature1);
				temperatureList2.add(temperature2);
				temperatureList3.add(temperature3);
				temperatureList4.add(temperature4);
			}
		}

		samples = timeList.size();

		// Create series
		chartSeries0 = new ChartSeries();
		chartSeries1 = new ChartSeries();
		chartSeries2 = new ChartSeries();
		chartSeries3 = new ChartSeries();
		chartSeries4 = new ChartSeries();
		
		// Set legend
		chartSeries0.setLabel("T0");
		chartSeries1.setLabel("T1");
		chartSeries2.setLabel("T2");
		chartSeries3.setLabel("T3");
		chartSeries4.setLabel("T4");

		// New line model
		LineChartModel lineChartModel_new = new LineChartModel();
		
		// Init
		lineChartModel_new = init(lineChartModel_new);
		
		// Inert new data
		for (int i = 0; i < timeList.size(); i++) {
			chartSeries0.set(timeList.get(i), temperatureList0.get(i));
			chartSeries1.set(timeList.get(i), temperatureList1.get(i));
			chartSeries2.set(timeList.get(i), temperatureList2.get(i));
			chartSeries3.set(timeList.get(i), temperatureList3.get(i));
			chartSeries4.set(timeList.get(i), temperatureList4.get(i));
		}

		// Insert in model
		lineChartModel_new.addSeries(chartSeries0);
		lineChartModel_new.addSeries(chartSeries1);
		lineChartModel_new.addSeries(chartSeries2);
		lineChartModel_new.addSeries(chartSeries3);
		lineChartModel_new.addSeries(chartSeries4);

		// Replace
		lineChartModel = lineChartModel_new;
	}

	public LineChartModel getLineChartModel() {
		return lineChartModel;
	}

	public void setLineChartModel(LineChartModel lineChartModel) {
		this.lineChartModel = lineChartModel;
	}

	public int getSamples() {
		return samples;
	}

	public void setSamples(int samples) {
		this.samples = samples;
	}

}
