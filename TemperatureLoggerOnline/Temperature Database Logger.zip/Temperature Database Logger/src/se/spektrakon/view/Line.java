package se.spektrakon.view;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import org.primefaces.PrimeFaces;

import se.spektrakon.database.JdbcMethods;
import se.spektrakon.hardware.Computer;
import se.spektrakon.start.Queuing;

@ManagedBean
@ApplicationScoped
public class Line extends Thread{
	
	private Computer computer;
	private Chart chart;
	private DateTimeFormatter dateTimeFormatter;
	private boolean start;
	private int sampleTime;
	private int countTime;
	private JdbcMethods jdbcMethods;

	public Line(Computer computer, JdbcMethods jdbcMethods) {
		this.computer = computer;
		chart = new Chart();		
		dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		start = false; // Init status
		sampleTime = 1; // Init sample time
		countTime = 1; // Init count time
		this.jdbcMethods = jdbcMethods;
	}

	@Override
	public void run() {
		while(true) {
			boolean callLineThread = Queuing.callLineThread;
			if(callLineThread && start) {
				
				// First get the temperature
				double temperature0 = computer.getMcp3008().getTemperature0();
				double temperature1 = computer.getMcp3008().getTemperature1();
				double temperature2 = computer.getMcp3008().getTemperature2();
				double temperature3 = computer.getMcp3008().getTemperature3();
				double temperature4 = computer.getMcp3008().getTemperature4();
				
				// Get time in hh:mm format
				LocalDateTime now = LocalDateTime.now();
				String time = dateTimeFormatter.format(now);
				
				
				if(countTime >= sampleTime) {
					// Then update the chart
					chart.addToChart(temperature0, temperature1, temperature2, temperature3, temperature4, time);
					countTime = 1; // Reset
	
					// Write do database if we have connection
					if(jdbcMethods.isConnectionStatus()) {
						jdbcMethods.insert(time, temperature0, temperature1, temperature2, temperature3, temperature4);
					}else {
						jdbcMethods.setWritingStatus("Not connected to MySQL");
					}

					
				}else {
					countTime++;
				}
				
				
				// Sleep 1 second
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				// Done
				Queuing.callComputerThread = true;
				Queuing.callLineThread = false;
			}
		}
	}

	public JdbcMethods getJdbcMethods() {
		return jdbcMethods;
	}

	public void setJdbcMethods(JdbcMethods jdbcMethods) {
		this.jdbcMethods = jdbcMethods;
	}

	public Chart getChart() {
		return chart;
	}

	public void setChart(Chart chart) {
		this.chart = chart;
	}


	public boolean isStart() {
		return start;
	}

	public void setStart(boolean start) {
		this.start = start;
	}
	
	public void addMessage() {
        String summary = start ? "Started" : "Stopped";
        String zoom = start ? "You cannot zoom while sampling" : "You can zoom now";
        if(start) {
        	PrimeFaces pf = PrimeFaces.current();
        	pf.executeScript("PF('poll').start();");
        }else {
        	PrimeFaces pf = PrimeFaces.current();
        	pf.executeScript("PF('poll').stop();");
        }
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, summary, zoom));
    }

	public int getSampleTime() {
		return sampleTime;
	}

	public void setSampleTime(int sampleTime) {
		this.sampleTime = sampleTime;
	}
	
	
	
	
}
