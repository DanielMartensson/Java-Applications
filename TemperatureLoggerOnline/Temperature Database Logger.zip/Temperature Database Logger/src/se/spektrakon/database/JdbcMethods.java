package se.spektrakon.database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

@ManagedBean
@ApplicationScoped
public class JdbcMethods {
	
	private Connection connection = null;
	private String URL;
	private String USER;
	private String PASS;
	private String TABLE;
	private String SCHEMA;
	private boolean connectionStatus;
	private String connectionButton;
	private String writingStatus;
	
	public JdbcMethods() throws ClassNotFoundException {
		// Driver 
		Class.forName("com.mysql.cj.jdbc.Driver");
		connectionStatus = false; // Initial status
		connectionButton = "Not connected"; // Initial button name
	}
	
	/*
	 * This is a decision tree for connection
	 */
	public void connect_or_disconnect() {
		if(connectionStatus) {
			disconnect();
			
		}else {
			connect();
			
		}
	}
	
	/*
	 * Connect to the database
	 */
	public void connect() {
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://" + URL + "/" + SCHEMA, USER, PASS);
			printStatus("Success", "Connected to MySQL");
			connectionStatus = true;
			connectionButton = "Connected";
			checkIfTableExist();
		} catch (Exception e) {
			// If we cannot connect - send message as ajax message
			printStatus("Error", "Cannot connect to MySQL. Time zone is right at MySQL?" + e.getMessage());
		}
	}
	
	/*
	 * This method check if table exist
	 */
	private void checkIfTableExist() {
		
		try {
			DatabaseMetaData dbm = connection.getMetaData();
			ResultSet rs = dbm.getTables(null, null, TABLE, null);
		    if (!rs.next()) {
		    	// Not exist - create one
		    	createTable();
		    } 
		} catch (Exception e) {
			System.out.println("Error, Cannot search for tables");
		}
	    
	}

	/*
	 * Close the connection
	 */
	public void disconnect() {
		try {
			connection.close();
			printStatus("Success", "Closed the connection");
			connectionStatus = false;
			connectionButton = "Not connected";
		} catch (Exception e) {
			printStatus("Error", "Cannot close the connection" + e.getMessage());
		}
	}
	
	/*
	 * Create the table inside the database
	 */
	public void createTable() {
		try {
			Statement statement = connection.createStatement();
			String query = "CREATE TABLE " + SCHEMA + "." + TABLE + " (Date VARCHAR(255),Temperature0 DOUBLE,Temperature1 DOUBLE,Temperature2 DOUBLE,Temperature3 DOUBLE,Temperature4 DOUBLE)";
			statement.execute(query);
			printStatus("Success", "Created a table to MySQL");
		} catch (Exception e) {
			// If we cannot create table - send message as ajax message
			printStatus("Warning", "Cannot create table. Probably already exist" + e.getMessage());
		}
	      
	}
	
	/*
	 * Insert data to database
	 */
	public void insert(String date, double temperature0, double temperature1,double temperature2, double temperature3, double temperature4) {
		
		// Round to .00 decimals
		temperature0 = Math.round(temperature0 * 100.0) / 100.0;
		temperature1 = Math.round(temperature1 * 100.0) / 100.0;
		temperature2 = Math.round(temperature2 * 100.0) / 100.0;
		temperature3 = Math.round(temperature3 * 100.0) / 100.0;
		temperature4 = Math.round(temperature4 * 100.0) / 100.0;
		
		
		try {
			Statement statement = connection.createStatement();
			String query = "INSERT INTO " + SCHEMA + "." + TABLE + " (Date,Temperature0,Temperature1,Temperature2,Temperature3,Temperature4) VALUES ('" + date + "'," + temperature0 + "," + temperature1 + "," + temperature2 + "," + temperature3 + "," + temperature4 + ")";
			boolean sendingStatus = statement.execute(query);
			if(!sendingStatus) {
				writingStatus = "Sending OK. Connection OK";
			}else {
				writingStatus = "Sending ERROR. Connection OK";
			}
		} catch (Exception e) {
			writingStatus = "Sending ERROR. Connection ERROR";
		}
		
	}
	
	public String getWritingStatus() {
		return writingStatus;
	}

	public void setWritingStatus(String writingStatus) {
		this.writingStatus = writingStatus;
	}

	/*
	 * Print out ajax message
	 */
	private void printStatus(String upperLine, String underLine) {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, upperLine, underLine));
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String uRL) {
		URL = uRL;
	}

	public String getUSER() {
		return USER;
	}

	public void setUSER(String uSER) {
		USER = uSER;
	}

	public String getPASS() {
		return PASS;
	}

	public void setPASS(String pASS) {
		PASS = pASS;
	}

	public String getTABLE() {
		return TABLE;
	}

	public void setTABLE(String tABLE) {
		TABLE = tABLE;
	}

	public String getConnectionButton() {
		return connectionButton;
	}

	public void setConnectionButton(String connectionButton) {
		this.connectionButton = connectionButton;
	}

	public boolean isConnectionStatus() {
		return connectionStatus;
	}

	public void setConnectionStatus(boolean connectionStatus) {
		this.connectionStatus = connectionStatus;
	}

	public String getSCHEMA() {
		return SCHEMA;
	}

	public void setSCHEMA(String sCHEMA) {
		SCHEMA = sCHEMA;
	}
	
	
	
}
