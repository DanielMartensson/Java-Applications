package se.spektrakon.hardware;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SerialLock {
	private final String cpuInfo = "cat /proc/cpuinfo";
	private final String lookFor = "Serial";
	private String cpuSerial = "";
	private boolean correctCPU = false;
	
	/*
	 * Constructor who check if it's the correct CPU
	 */
	public SerialLock(String serialNumberCode) {
		
		try {
			Process proc = Runtime.getRuntime().exec(cpuInfo);
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			// Look for the serial
			String cpuText = null;
			while ((cpuText = stdInput.readLine()) != null) {
				if(cpuText.contains(lookFor)) {
					String[] cpuTextSplit = cpuText.split(":"); // Split 
					cpuSerial = cpuTextSplit[1].replaceAll(" ", ""); // Remove space
				}
			}
			
			// Check if there is correct cpu
			if(cpuSerial.contains(serialNumberCode)) {
				correctCPU = true;
			}

		} catch (IOException e) {

		}

	}

	public boolean isCorrectCPU() {
		return correctCPU;
	}

}
