package se.spektrakon.hardware;

import com.pi4j.io.spi.SpiChannel;
import com.pi4j.io.spi.SpiDevice;
import com.pi4j.io.spi.SpiFactory;

import se.spektrakon.start.Queuing;

public class Computer extends Thread {
	/*
	 * Init the SPI
	 */
	public SpiFactory spiFactory;
	public SpiDevice spiDevice;

	/*
	 * Init the MCP3008
	 */
	private Mcp3008 mcp3008;

	/*
	 * Init the Raspberry SPI
	 */
	public Computer() {

		try {
			spiDevice = SpiFactory.getInstance(SpiChannel.CS0, SpiDevice.DEFAULT_SPI_SPEED, SpiDevice.DEFAULT_SPI_MODE);
		} catch (Exception e) {
			System.out.println("Cannot init SPI");
		}

		this.mcp3008 = new Mcp3008(spiDevice);
	}

	/*
	 * Read the temperature sensors 0-5 volt with 10 bit ADC (non-Javadoc)
	 * 
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run() {
		while (true) {
			boolean callComputerThread = Queuing.callComputerThread;
			if (callComputerThread) {
				
				// Call and then read temperature
				mcp3008.callMCP3008();
				mcp3008.readMCP3008();

				// Done
				Queuing.callComputerThread = false;
				Queuing.callLineThread = true;
			}
		}

	}

	public Mcp3008 getMcp3008() {
		return mcp3008;
	}

	public void setMcp3008(Mcp3008 mcp3008) {
		this.mcp3008 = mcp3008;
	}

}
