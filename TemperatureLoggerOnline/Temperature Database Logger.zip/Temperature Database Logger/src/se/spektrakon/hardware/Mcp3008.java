package se.spektrakon.hardware;

import java.io.IOException;

import com.pi4j.io.spi.SpiDevice;

public class Mcp3008 {
	private SpiDevice spiDevice;
	private double temperature0;
	private double temperature1;
	private double temperature2;
	private double temperature3;
	private double temperature4;
	private int adc0;
	private int adc1;
	private int adc2;
	private int adc3;
	private int adc4;
	private byte[] resultChannel0;
	private byte[] resultChannel1;
	private byte[] resultChannel2;
	private byte[] resultChannel3;
	private byte[] resultChannel4;

	/*
	 * Init the spiDevice
	 */
	public Mcp3008(SpiDevice spiDevice) {
		this.spiDevice = spiDevice;
	}
	
	/*
	 * Call the MCP3008
	 */
	public void callMCP3008() {
		try {
			resultChannel0 = spiDevice.write(data((short) 0));
			resultChannel1 = spiDevice.write(data((short) 1));
			resultChannel2 = spiDevice.write(data((short) 2));
			resultChannel3 = spiDevice.write(data((short) 3));
			resultChannel4 = spiDevice.write(data((short) 4));
		} catch (IOException e) {
			System.out.println("Cannot call MCP3008");
		}
	}

	/*
	 * Read the data sheet if you want to understand this
	 */
	private byte[] data(short channel) {

		byte[] data = new byte[] { (byte) 0b00000001, // first byte, start bit
				(byte) (0b10000000 | (((channel & 7) << 4))), // second byte transmitted -> (SGL/DIF = 1, D2=D1=D0=0)
				(byte) 0b00000000 // third byte transmitted....don't care
		};
		
		return data;
	}
	
	/*
	 * Convert the binary to decimal. Read the MCP9700AE data sheet
	 */
	public void readMCP3008() {
		adc0 = ((resultChannel0[1]<< 8) & 0b1100000000); //merge data[1] & data[2] to get 10-bit result
		adc0 |=  (resultChannel0[2] & 0xff);
		temperature0 = (double) ((((double) adc0)/1024 * 5.0 - 0.5)*50)/0.5;
		
        adc1 = ((resultChannel1[1]<< 8) & 0b1100000000); //merge data[1] & data[2] to get 10-bit result
        adc1 |=  (resultChannel1[2] & 0xff);
        temperature1 = (double) ((((double) adc1)/1024 * 5.0 - 0.5)*50)/0.5;
        
        adc2 = ((resultChannel2[1]<< 8) & 0b1100000000); //merge data[1] & data[2] to get 10-bit result
        adc2 |=  (resultChannel2[2] & 0xff);
        temperature2 = (double) ((((double) adc2)/1024 * 5.0 - 0.5)*50)/0.5;
        
        adc3 = ((resultChannel3[1]<< 8) & 0b1100000000); //merge data[1] & data[2] to get 10-bit result
        adc3 |=  (resultChannel3[2] & 0xff);
        temperature3 = (double) ((((double) adc3)/1024 * 5.0 - 0.5)*50)/0.5;
        
        adc4 = ((resultChannel4[1]<< 8) & 0b1100000000); //merge data[1] & data[2] to get 10-bit result
        adc4 |=  (resultChannel4[2] & 0xff);
        temperature4 = (double) ((((double) adc4)/1024 * 5.0 - 0.5)*50)/0.5;
	}

	public double getTemperature0() {
		return temperature0;
	}

	public void setTemperature0(double temperature0) {
		this.temperature0 = temperature0;
	}

	public double getTemperature1() {
		return temperature1;
	}

	public void setTemperature1(double temperature1) {
		this.temperature1 = temperature1;
	}

	public int getAdc0() {
		return adc0;
	}

	public void setAdc0(int adc0) {
		this.adc0 = adc0;
	}

	public int getAdc1() {
		return adc1;
	}

	public void setAdc1(int adc1) {
		this.adc1 = adc1;
	}

	public double getTemperature2() {
		return temperature2;
	}

	public void setTemperature2(double temperature2) {
		this.temperature2 = temperature2;
	}

	public double getTemperature3() {
		return temperature3;
	}

	public void setTemperature3(double temperature3) {
		this.temperature3 = temperature3;
	}

	public double getTemperature4() {
		return temperature4;
	}

	public void setTemperature4(double temperature4) {
		this.temperature4 = temperature4;
	}

	public int getAdc2() {
		return adc2;
	}

	public void setAdc2(int adc2) {
		this.adc2 = adc2;
	}

	public int getAdc3() {
		return adc3;
	}

	public void setAdc3(int adc3) {
		this.adc3 = adc3;
	}

	public int getAdc4() {
		return adc4;
	}

	public void setAdc4(int adc4) {
		this.adc4 = adc4;
	}


}
